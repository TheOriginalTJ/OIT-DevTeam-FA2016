package OIT_Dev;

public class Population {

	Schedule[] schedules;

	/*
	 * Constructors
	 */
	// Create a population
	public Population(int populationSize, boolean initialize) {
		schedules = new Schedule[populationSize];
		// Initialize population
		if (initialize) {
			// Loop and create schedule
			for (int i = 0; i < size(); i++) {
				Schedule newSched = new Schedule();
				newSched.generateSched();
				saveSched(i, newSched);
			}
		}
	}

	/* Getters */
	public Schedule getSched(int index) {
		return schedules[index];
	}

	public Schedule getFittest() {
		Schedule fittest = schedules[0];
		// Loop through population to find fittest
		for (int i = 0; i < size(); i++) {
			if (fittest.getFitness() <= getSched(i).getFitness()) {
				fittest = getSched(i);
			}
		}
		return fittest;
	}

	/* Public methods */
	// Get population size
	public int size() {
		return schedules.length;
	}

	// Save schedule
	public void saveSched(int index, Schedule sch) {
		schedules[index] = sch;
	}
}
